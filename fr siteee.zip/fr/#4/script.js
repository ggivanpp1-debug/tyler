const translations = {
  ru: {
    title: 'Привет, я <span style="color:#f97316">Zhanuzak</span> 👋',
    'about-text': 'Я frontend разработчик и создаю современные сайты.',
    navAbout: 'Обо мне', navSkills: 'Навыки', navProjects: 'Проекты', navContact: 'Контакты',
    secAbout: 'Обо мне', secSkills: 'Навыки', secProjects: 'Проекты', secContact: 'Контакты',
    btnPS: 'ProfiSpace', btnTg: 'Telegram',
    descPS: 'Фриланс платформа с авторизацией, лентой заказов и чатом.',
    descLand: 'Сайт для бизнеса с адаптивным дизайном.',
    descPort: 'Этот сайт — моё портфолио.',
    live: 'Live сайт',
    ctTitle: 'Готов к работе', ctSub: 'Напишите мне — отвечу быстро!',
  },
  en: {
    title: 'Hi, I\'m <span style="color:#f97316">Zhanuzak</span> 👋',
    'about-text': 'I am a frontend developer creating modern websites.',
    navAbout: 'About', navSkills: 'Skills', navProjects: 'Projects', navContact: 'Contact',
    secAbout: 'About me', secSkills: 'Skills', secProjects: 'Projects', secContact: 'Contact',
    btnPS: 'ProfiSpace', btnTg: 'Telegram',
    descPS: 'Freelance platform with auth, job feed and chat.',
    descLand: 'Business website with responsive design.',
    descPort: 'This site — my portfolio.',
    live: 'Live site',
    ctTitle: 'Open to work', ctSub: 'Message me — I reply fast!',
  },
  kz: {
    title: 'Сәлем, мен <span style="color:#f97316">Zhanuzak</span> 👋',
    'about-text': 'Мен заманауи сайттар жасайтын frontend әзірлеушімін.',
    navAbout: 'Мен туралы', navSkills: 'Дағдылар', navProjects: 'Жобалар', navContact: 'Байланыс',
    secAbout: 'Мен туралы', secSkills: 'Дағдылар', secProjects: 'Жобалар', secContact: 'Байланыс',
    btnPS: 'ProfiSpace', btnTg: 'Telegram',
    descPS: 'Авторизациямен, тапсырыс лентасымен және чатпен фриланс платформасы.',
    descLand: 'Адаптивті дизайны бар бизнес сайты.',
    descPort: 'Бұл сайт — менің портфолиом.',
    live: 'Live сайт',
    ctTitle: 'Жұмысқа дайынмын', ctSub: 'Маған жазыңыз — жылдам жауап беремін!',
  }
};

function setLang(lang) {
  const d = translations[lang];

  document.getElementById('title').innerHTML = d['title'];
  document.getElementById('about-text').textContent = d['about-text'];

  document.querySelectorAll('[data-t]').forEach(el => {
    const key = el.getAttribute('data-t');
    if (d[key]) el.textContent = d[key];
  });

  document.querySelectorAll('.lang-btns button').forEach(btn => {
    btn.classList.toggle('active', btn.textContent.toLowerCase() === lang);
  });
}

function contact() {
  window.open('https://t.me/zhanuzak', '_blank');
}
