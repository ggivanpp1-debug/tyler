function showAlert() {
alert("Это мой лучший проект 😎");
}

function contactMe() {
alert("Telegram: @your_username");
}